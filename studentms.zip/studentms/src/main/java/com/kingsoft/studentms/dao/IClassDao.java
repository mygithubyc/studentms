package com.kingsoft.studentms.dao;

public interface IClassDao extends IBasicDao{
	
}
