package com.kingsoft.studentms.dao;

public interface ITeacherDao extends IBasicDao{

}
