package com.kingsoft.studentms.dao;

public interface ICourseAssignDao {

}
