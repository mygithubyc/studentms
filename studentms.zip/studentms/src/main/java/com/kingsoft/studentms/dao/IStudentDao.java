package com.kingsoft.studentms.dao;

public interface IStudentDao extends IBasicDao{

}
