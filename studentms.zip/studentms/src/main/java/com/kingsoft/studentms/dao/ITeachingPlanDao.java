package com.kingsoft.studentms.dao;

public interface ITeachingPlanDao extends IBasicDao{

}
