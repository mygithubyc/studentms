package com.kingsoft.studentms.dao;

public interface IDepartmentDao extends IBasicDao{

}
